/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/Device",
        "dashboard/model/models",
        'sap/ui/model/json/JSONModel',
        './controller/SelectDataset'
    ],
    function (UIComponent, Device, models, JSONModel, SelectDataset) {
        "use strict";

        return UIComponent.extend("dashboard.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);
                
                const ToolBarModel = new JSONModel({
                    selectedKey: 'dashboard',
                    navigation: [
                        {   
                            icon: 'sap-icon://bbyd-dashboard',
                            key: 'dashboard',
                            text: 'Dashboard'
                        },
                        {
                            icon: 'sap-icon://add-document',
                            key: 'managedocuments',
                            text: 'Manage Documents'
                        }
                    ]
                });

                const DashboardTilesModel = new JSONModel({
                    fileSource: 'Click to select dataset',
                    totalRITMs: 0,
                    uniqueCreators: 0,
                    topCreators: '',
                    dateRange: '',
                    busiestDays: '',
                    avgRITMsPerDay: 0
                });

                // enable routing
                this.getRouter().initialize();

                this._SelectDataset = new SelectDataset(this.getRootControl());

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
                this.setModel(ToolBarModel, 'ToolBarModel');
                this.setModel(DashboardTilesModel, 'DashboardTilesModel');
            },
            exit: function () {
                this._SelectDataset.destroy();
                delete this._SelectDataset;
            },
            openDialogSelectDataset: function(oController) {
                this._SelectDataset.open(oController);
            }
        });
    }
);